## 💻 How to Run

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
